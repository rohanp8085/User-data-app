import { Box, Button, Container, InputLabel, MenuItem, Select, TextField, Typography } from '@mui/material'
import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { getcountry, getstate } from '../features/ListSlice'
import Modal from '@mui/material/Modal';


const style = {
    position: 'absolute',
    top: '55%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 500,
    bgcolor: 'background.paper',
    // border: '2px solid /#000',
    boxShadow: 24,
    p: 4,
};

const Home = () => {

    const { lists, states } = useSelector(state => state.list)
    console.log(states.list)

    const [open, setOpen] = React.useState(false);
    const handleOpen = () => {

        setOpen(true)
    };
    const handleClose = () => setOpen(false);



    const dispatch = useDispatch()
    const [text, setText] = useState({
        name: "",
        email: "",
        number: "",
        country: "",
        state: "",

    })
    const [formData, setFormData] = useState({

        names: "",
        emails: "",
        numbers: "",
        countrys: "",
        stateses: "",


    })

    const { names, emails, numbers, countrys, stateses } = formData

    useEffect(() => {
        dispatch(getcountry())
        dispatch(getstate())

    }, [])
    const { name, email, number, country, state } = text

    const handleChange = (e) => {
        setText({
            ...text,
            [e.target.name]: e.target.value
        })
    }
    const handleSubmit = (e) => {
        e.preventDefault()
        setFormData(text)
        console.log(text)

    }
    return (
        <>


            <Container maxWidth="sm" sx={{ padding: 5 }} >



                <Typography variant="h5" component="h2" align="center">
                    Home
                </Typography>
                <TextField
                    type="text"
                    name="name"
                    placeholder='name'
                    variant="outlined"
                    fullWidth
                    margin="normal"
                    value={name}
                    required
                />
                <TextField
                    type="email"
                    name="email"
                    placeholder='email'
                    variant="outlined"
                    fullWidth
                    margin="normal"
                    value={email}
                    required
                />
                <TextField
                    type="number"
                    name="number"
                    placeholder='number'
                    variant="outlined"
                    fullWidth
                    margin="normal"
                    value={number}
                    required
                />
                <TextField
                    type="text"
                    name="city"
                    placeholder='country'
                    variant="outlined"
                    fullWidth
                    margin="normal"
                    value={country}
                    required
                />
                <TextField
                    type="text"
                    name="state"
                    placeholder='state'
                    variant="outlined"
                    fullWidth
                    margin="normal"
                    value={state}
                    required
                />




            </Container>

            <button className='add-btn' onClick={handleOpen}>X</button>
            <Modal
                open={open}
                
                aria-labelledby="modal-modal-title"
                aria-describedby="modal-modal-description"
            >
                <Box sx={style}>
                    <form method='post' onSubmit={handleSubmit}>
                        <TextField
                            type="text"
                            name="name"
                            label="Name"
                            variant="outlined"
                            fullWidth
                            margin="normal"
                            value={name}
                            onChange={handleChange}
                            required
                        />
                        <TextField
                            type="email"
                            name="email"
                            label="Email"
                            variant="outlined"
                            fullWidth
                            margin="normal"
                            value={email}
                            onChange={handleChange}
                            required
                        />
                        <TextField
                            type="number"
                            name="number"
                            label="Number"
                            variant="outlined"
                            fullWidth
                            margin="normal"
                            value={number}
                            onChange={handleChange}
                            required
                        />
                        <InputLabel id="demo-simple-select-label">{country}</InputLabel>
                        <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"

                            name="country"
                            label="country"
                            fullWidth

                            onChange={handleChange}
                            value={country}
                            required
                        >

                            {
                                lists.list.map(item => <MenuItem key={item.id} item={item} value={item.name}>{item.name}</MenuItem>)
                            }


                        </Select>
                        <InputLabel id="demo-simple-select-label">{state}</InputLabel>
                        <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            // value={age}
                            name="state"

                            fullWidth
                            label="state"
                            onChange={handleChange}
                            value={state}
                            required
                        >
                            {
                                states.list.map(item => <MenuItem key={item.id} item={item} value={item.name} >{item.name}</MenuItem>)
                            }

                        </Select>


                        <Button
                        onClick={handleClose}
                            type="submit"
                            variant="contained"
                            color="success"
                            fullWidth
                            size="large"
                            method="post"
                            style={{ marginTop: '1rem' }}
                        >
                            Addlist
                        </Button>
                    </form>
                </Box>

            </Modal>
        </>



    )
}

export default Home
