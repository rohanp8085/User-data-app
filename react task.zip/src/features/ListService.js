import axios from "axios"

   
const API_URL = "/api/"  

const createlist = async(userData , token) =>{

    const config = {
        headers : {
            Authorization : `Bearer ${token}`
        }
    }
   const response = await axios.get(API_URL + "core/countries", config, userData)
   localStorage.setItem("country" , JSON.stringify(response.data))
     console.log(response.data)
     return response.data
}

const getstate = async(userData , token) =>{

    const config = {
        headers : {
            Authorization : `Bearer ${token}`
        }
    }
   const response = await axios.get(API_URL + "core/states", config, userData)
   localStorage.setItem("state" , JSON.stringify(response.data))
     console.log(response.data)
     return response.data
}



const ListService = {
    createlist,
    getstate
}

export default ListService